A reservation system with pure javascript
